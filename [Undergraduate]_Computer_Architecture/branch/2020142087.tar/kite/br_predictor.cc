#include <cstring>
#include "br_predictor.h"

br_predictor_t::~br_predictor_t() {
    // Deallocate the PHT.
    delete [] pht;
}

br_target_buffer_t::~br_target_buffer_t() {
    // Deallocate the target address array.
    delete [] buffer;
}



/**********************************
* Assignment 4: Branch Prediction *
***********************************/

/* Add variable: predicted_pht_index in inst.h                               */
/* unsigned predicted_pht_index;       // Index of pht used for prediction   */
/* It stores Index of pht and carry it along the processor pipeline          */

// Branch predictor
br_predictor_t::br_predictor_t(unsigned m_hist_len, unsigned m_pht_bits) :
    bhr(0),
    pht(0),
    h(m_hist_len),
    p(m_pht_bits) {
    // Create a pattern history table (PHT).
    pht = new uint8_t[(1 << h) * (1 << p)];

    // calculate pht size
    int size = (1 << h) * (1 << p);
    
    // Initialize the PHT entries to weakly not taken (01)
    // Initializing to weakly not taken (01) is good because we don't have to predict the first branch
    // also, weakly not taken (01) can go to either weakly taken (10) or strongly not taken (00)
    for (int i = 0; i < size; ++i)
    {
        pht[i] = 1;
    }
}
// Is a branch predicted to be taken?
bool br_predictor_t::is_taken(inst_t *m_inst) {
    
    // Calculate the row index using XOR ("the lowest four bits of bhr" XOR "lowest four bits of (PC >> 2)")
    unsigned row_index = (bhr ^ (m_inst->pc >> 2)) & 0xF;  // Assuming h = 4
    
    // Calculate the column index using lowest four bits of (PC >> 2)
    unsigned col_index = (m_inst->pc >> 2) & 0xF;  // Assuming p = 4

    // Calculate the index in the 1-D pht array
    // We consider 1-D array as 2-D array, so index is calculated as row_index*16 + col_index
    unsigned pht_index = (row_index << 4) + col_index;  // Assuming 2^4 columns as per p = 4

    // Store the pht index in the m_inst for later use
    // We should use pht_index to update PHT when the actual result is calculated
    m_inst->predicted_pht_index = pht_index;

    // Get the counter value from pht and make a prediction
    uint8_t counter_value = pht[pht_index];
    
    // not taken if pht counter value is 0 or 1
    // taken if pht counter value is 2 or 3 
    bool taken = counter_value >= 2;

    return taken;
}

// Update a prediction counter.
void br_predictor_t::update(inst_t *m_inst) {
    // Update the branch history register (BHR)
    // Shift bhr left by one bit and insert the latest branch result in the LSB
    bhr = (bhr << 1) | (m_inst->branch_taken & 0x01);

    // Get the pht index from m_inst for updating pht entry 
    unsigned pht_index = m_inst->predicted_pht_index;

    // Update the PHT comparing with the actual result of the branch
    if (m_inst->branch_taken) 
    {
        // If the branch was taken, increment the counter
        // counter value should not exceed 3 (2-bit counter)
        if (pht[pht_index] < 3) 
        {
            pht[pht_index]++;
        }
    }
    else 
    {
        // If the branch was not taken, decrement the counter
        // counter value should not go down below 0 (2-bit counter)
        if (pht[pht_index] > 0) 
        {
            pht[pht_index]--;
        }
    }
}



// Branch target buffer
br_target_buffer_t::br_target_buffer_t(uint64_t m_size) :
    num_entries(m_size),
    buffer(0) {
    // Create a direct-mapped branch target buffer (BTB).
    buffer = new uint64_t[num_entries];

    // Initialize the buffer entries to zero
    for (uint64_t i = 0; i < num_entries; ++i) 
    {
        buffer[i] = 0;
    }
}
// Get a branch target address.
uint64_t br_target_buffer_t::get_target(uint64_t m_pc) {
    // Calculate the index using the right shift and AND operation
    // As num_entries is 16, I used mask instead of %num_entries 
    // num_entries = 16 (a power of two), mask = num_entries - 1 = 4'b1111
    uint64_t mask = num_entries - 1;  // mask = 4'b1111
    uint64_t index = (m_pc >> 2) & mask; // get lower 4 bits

    // Return the branch target address stored in the buffer
    return buffer[index];
}

// Update the branch target buffer.
void br_target_buffer_t::update(uint64_t m_pc, uint64_t m_target_addr) {
    // Calculate the index using the right shift and AND operation
    // num_entries = 16 (a power of two), mask = num_entries - 1 = 4'b1111
    uint64_t mask = num_entries - 1;  // mask = 4'b1111
    uint64_t index = (m_pc >> 2) & mask;

    // Update the branch target buffer with the actual branch target address
    buffer[index] = m_target_addr;
}

